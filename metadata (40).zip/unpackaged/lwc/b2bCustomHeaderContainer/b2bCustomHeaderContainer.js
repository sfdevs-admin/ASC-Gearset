import { LightningElement } from 'lwc';
export default class B2bCustomHeaderContainer extends LightningElement {

}