<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>223</label>
    <protected>false</protected>
    <values>
        <field>Country_Code__c</field>
        <value xsi:type="xsd:string">TM</value>
    </values>
    <values>
        <field>Country_Name__c</field>
        <value xsi:type="xsd:string">Turkmenistan</value>
    </values>
    <values>
        <field>Currency_Code__c</field>
        <value xsi:type="xsd:string">USD</value>
    </values>
    <values>
        <field>ISO_code__c</field>
        <value xsi:type="xsd:string">TKM</value>
    </values>
</CustomMetadata>
