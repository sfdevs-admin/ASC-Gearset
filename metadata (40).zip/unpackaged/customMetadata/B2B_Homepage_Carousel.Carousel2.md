<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Carousel2</label>
    <protected>false</protected>
    <values>
        <field>Description__c</field>
        <value xsi:type="xsd:string">Description for image 2</value>
    </values>
    <values>
        <field>Heading__c</field>
        <value xsi:type="xsd:string">Heading 2</value>
    </values>
    <values>
        <field>Image_URL__c</field>
        <value xsi:type="xsd:string">/sfsites/c/cms/delivery/media/MCMZTIXZZBXBEIZGLBWMBFX33BMI?version=2.1</value>
    </values>
    <values>
        <field>Link_URL__c</field>
        <value xsi:type="xsd:string">/intermediates</value>
    </values>
    <values>
        <field>Sort_Order__c</field>
        <value xsi:type="xsd:double">3.0</value>
    </values>
    <values>
        <field>URL_Target__c</field>
        <value xsi:type="xsd:string">_blank</value>
    </values>
</CustomMetadata>
